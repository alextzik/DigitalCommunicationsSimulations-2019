function varargout = modulation_selection(varargin)

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @modulation_selection_OpeningFcn, ...
                   'gui_OutputFcn',  @modulation_selection_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT

function modulation_selection_OpeningFcn(hObject, eventdata, handles, varargin)

handles.output = hObject;
guidata(hObject, handles);

function varargout = modulation_selection_OutputFcn(hObject, eventdata, handles) 
varargout{1} = handles.output;

function Hamming_Callback(hObject, eventdata, handles)

    if ( get(handles.psk,'Value') || get(handles.pam,'Value') || get(handles.qam,'Value') ) ...
            && ( get(handles.symbols2,'Value') || get(handles.symbols4,'Value') || get(handles.symbols8,'Value') || get(handles.symbols16,'Value') || get(handles.symbols64,'Value'))...
            && ( get(handles.Hamming,'Value'))
        
        set(handles.Ok,'Enable','on');      
    else
        set(handles.Ok,'Enable','off');
    end    

function RS239_Callback(hObject, eventdata, handles)

    if ( get(handles.psk,'Value') || get(handles.pam,'Value') || get(handles.qam,'Value') ) ...
            && ( get(handles.symbols2,'Value') || get(handles.symbols4,'Value') || get(handles.symbols8,'Value') || get(handles.symbols16,'Value') || get(handles.symbols64,'Value'))...
            && ( get(handles.RS239,'Value'))
        
        set(handles.Ok,'Enable','on');
    else
        set(handles.Ok,'Enable','off');
    end

function RS223_Callback(hObject, eventdata, handles)

    if ( get(handles.psk,'Value') || get(handles.pam,'Value') || get(handles.qam,'Value') ) ...
            && ( get(handles.symbols2,'Value') || get(handles.symbols4,'Value') || get(handles.symbols8,'Value') || get(handles.symbols16,'Value') || get(handles.symbols64,'Value'))...
            && ( get(handles.RS223,'Value'))
        
        set(handles.Ok,'Enable','on');
    else
        set(handles.Ok,'Enable','off');
    end
    
function LTEturbo_Callback(hObject, eventdata, handles)

    if ( get(handles.psk,'Value') || get(handles.pam,'Value') || get(handles.qam,'Value') ) ...
            && ( get(handles.symbols2,'Value') || get(handles.symbols4,'Value') || get(handles.symbols8,'Value') || get(handles.symbols16,'Value') || get(handles.symbols64,'Value'))...
            && ( get(handles.LTEturbo,'Value'))
        
        set(handles.Ok,'Enable','on');
    else
        set(handles.Ok,'Enable','off');
    end
    
function None_Callback(hObject, eventdata, handles)

    if ( get(handles.psk,'Value') || get(handles.pam,'Value') || get(handles.qam,'Value') ) ...
            && ( get(handles.symbols2,'Value') || get(handles.symbols4,'Value') || get(handles.symbols8,'Value') || get(handles.symbols16,'Value') || get(handles.symbols64,'Value'))...
            && ( get(handles.None,'Value'))
        
        set(handles.Ok,'Enable','on');
    else
        set(handles.Ok,'Enable','off');
    end

function psk_Callback(hObject, eventdata, handles)

    set(handles.symbols2,'Enable','on');
    set(handles.symbols4,'Enable','on');
    set(handles.symbols8,'Enable','on');
    set(handles.symbols16,'Enable','off');
    set(handles.symbols64,'Enable','off');
    
    if ( get(handles.Hamming,'Value') || get(handles.RS239,'Value') || get(handles.RS223,'Value') || get(handles.LTEturbo,'Value') || get(handles.None,'Value'))...
            && ( get(handles.symbols2,'Value') || get(handles.symbols4,'Value') || get(handles.symbols8,'Value'))...
            && ( get(handles.psk,'Value'))
        
        set(handles.Ok,'Enable','on');
    else
        set(handles.Ok,'Enable','off');
    end

function pam_Callback(hObject, eventdata, handles)

function qam_Callback(hObject, eventdata, handles)
    
    set(handles.symbols2,'Enable','off');
    set(handles.symbols4,'Enable','off');
    set(handles.symbols8,'Enable','off');
    set(handles.symbols16,'Enable','on');
    set(handles.symbols64,'Enable','on');
    
    if ( get(handles.Hamming,'Value') || get(handles.RS239,'Value') || get(handles.RS223,'Value') || get(handles.LTEturbo,'Value') || get(handles.None,'Value'))...
            && ( get(handles.symbols16,'Value') || get(handles.symbols64,'Value'))...
            && ( get(handles.qam,'Value'))
        
        set(handles.Ok,'Enable','on');
    else
        set(handles.Ok,'Enable','off');
    end

function symbols2_Callback(hObject, eventdata, handles)

    if ( get(handles.Hamming,'Value') || get(handles.RS239,'Value') || get(handles.RS223,'Value') || get(handles.None,'Value') || get(handles.LTEturbo,'Value'))...
            && get(handles.psk,'Value')...
            && get(handles.symbols2,'Value')
        
        set(handles.Ok,'Enable','on');
    else
        set(handles.Ok,'Enable','off');
    end
 
function symbols4_Callback(hObject, eventdata, handles)

    if ( get(handles.Hamming,'Value') || get(handles.RS239,'Value') || get(handles.RS223,'Value') || get(handles.None,'Value') || get(handles.LTEturbo,'Value'))...
            && get(handles.psk,'Value')...
            && get(handles.symbols4,'Value')
        
        set(handles.Ok,'Enable','on');
    else
        set(handles.Ok,'Enable','off');
    end

function symbols8_Callback(hObject, eventdata, handles)

    if ( get(handles.Hamming,'Value') || get(handles.RS239,'Value') || get(handles.RS223,'Value') || get(handles.LTEturbo,'Value') || get(handles.None,'Value'))...
            && get(handles.psk,'Value')...
            && get(handles.symbols8,'Value')
        
        set(handles.Ok,'Enable','on');
    else
        set(handles.Ok,'Enable','off');
    end
    
    function symbols16_Callback(hObject, eventdata, handles)

    if ( get(handles.Hamming,'Value') || get(handles.RS239,'Value') || get(handles.RS223,'Value') || get(handles.LTEturbo,'Value') || get(handles.None,'Value'))...
            && get(handles.qam,'Value')...
            && get(handles.symbols16,'Value')
        
        set(handles.Ok,'Enable','on');
    else
        set(handles.Ok,'Enable','off');
    end
    
    function symbols64_Callback(hObject, eventdata, handles)

    if ( get(handles.Hamming,'Value') || get(handles.RS239,'Value') || get(handles.RS223,'Value') || get(handles.LTEturbo,'Value') || get(handles.None,'Value'))...
            && get(handles.qam,'Value')...
            && get(handles.symbols64,'Value')
        
        set(handles.Ok,'Enable','on');
    else
        set(handles.Ok,'Enable','off');
    end

function Ok_Callback(hObject, eventdata, handles)
uiresume
