function varargout = start(varargin)

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @start_OpeningFcn, ...
                   'gui_OutputFcn',  @start_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT

function start_OpeningFcn(hObject, eventdata, handles, varargin)
global numOfWindow
warning('off','MATLAB:HandleGraphics:ObsoletedProperty:JavaFrame');

numOfWindow = 1;

addpath('details','pictures','plotting');

handles.output = hObject;
guidata(hObject, handles);

firstpic = imread('pictures\first2','bmp');
image(firstpic);
set(gca,'Xtick',[],'Ytick',[]);
set(gca,'Xcolor',[ 0.725490196078431 0.729411764705882 0.792156862745098 ],...
   'Ycolor',[ 0.725490196078431 0.729411764705882 0.792156862745098 ]);

function varargout = start_OutputFcn(hObject, eventdata, handles) 
varargout{1} = handles.output;

function StaticText1_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function Go_Callback(hObject, eventdata, handles)
global numOfWindow

set(handles.Go,'Enable','off');
set(get(gcf,'JavaFrame'),'Minimized',1);

if numOfWindow == 1
    second;
else
    set(findobj('Tag','second'),'Visible','on');
end
set(handles.Go,'String','��������');

function Cancel_Callback(hObject, eventdata, handles)
clear
delete(gcf);

function start_DeleteFcn(hObject, eventdata, handles)
clear
close all hidden;
