function ShowIm(haxes,pic)

axes(haxes);
image(pic);
set(gca,'Xtick',[],'Ytick',[]);
set(gca,'Xcolor',[ 0.75 0.75 0.75 ],'Ycolor',[ 0.75 0.75 0.75]);

return
