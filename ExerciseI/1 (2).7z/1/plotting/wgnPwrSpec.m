function varargout = wgnPwrSpec(varargin)

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @wgnPwrSpec_OpeningFcn, ...
                   'gui_OutputFcn',  @wgnPwrSpec_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT

function wgnPwrSpec_OpeningFcn(hObject, eventdata, handles, varargin)
global timeCor lags

handles.output = hObject;
guidata(hObject, handles);

pwrSpec = abs(fftshift(fft(timeCor))); 

plot(handles.wgnAxes3,lags,10*log10(pwrSpec)-30,'Color',[0 .75 .75]);

xlim(handles.wgnAxes3,[lags(1,1) lags(1,length(lags))])
box off;

title(gca,'��������� ��������� ������ WN','Color',[.5,.5,.5],...
   'FontName','Calibri','FontWeight','bold','FontSize',11,'FontAngle','normal');
ylabel(gca,'������,(dBm/Hz)','Color',[.5,.5,.5],'FontName','Calibri',...
   'FontSize',11,'FontAngle','oblique');
xlabel(gca,'���������','Color',[.5,.5,.5],'FontName','Calibri','FontSize',11,'FontAngle','oblique');

l = legend('�.�.�. - ����������� �������','Location','SouthEast');
set(l,'EdgeColor',[.8 .8 .8],'FontName','Calibri');

function varargout = wgnPwrSpec_OutputFcn(hObject, eventdata, handles) 
varargout{1} = handles.output;

function PushbuttonGrid_Callback(hObject, eventdata, handles)
grid;

function Back2wgn_Callback(hObject, eventdata, handles)
t = findobj('Tag','PwrSpecPushbutton3');
set(t,'Enable','on');
delete(gcf);

function wgnPwrSpec_DeleteFcn(hObject, eventdata, handles)
t = findobj('Tag','PwrSpecPushbutton3');
set(t,'Enable','on');


%
