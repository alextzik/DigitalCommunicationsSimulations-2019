function varargout = SimulEye(varargin)


% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @SimulEye_OpeningFcn, ...
                   'gui_OutputFcn',  @SimulEye_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before SimulEye is made visible.
function SimulEye_OpeningFcn(hObject, eventdata, handles, varargin)
global MODULATOR

handles.output = hObject;
guidata(hObject, handles);

set(findobj('Tag','EyePushbutton1'),'Enable','off');

switch MODULATOR
    case 'bpsk'
        set(handles.SimulEye,'Name','BPSK ����: ��������� ��������');
        set(handles.EyePushbuttonQ,'Enable','off'); 
        
    case 'qpsk'
        set(handles.SimulEye,'Name','QPSK ����: ��������� ��������');
        
    case '8psk'
        set(handles.SimulEye,'Name','8PSK ����: ��������� ��������');
        
    case 'bqam'
        set(handles.SimulEye,'Name','BQAM ����: ��������� ��������');
        set(handles.EyePushbuttonQ,'Enable','off'); 
        
    case '16qam'
        set(handles.SimulEye,'Name','16QAM ����: ��������� ��������');
    
    case '64qam'
        set(handles.SimulEye,'Name','64QAM ����: ��������� ��������');
end


% --- Outputs from this function are returned to the command line.
function varargout = SimulEye_OutputFcn(hObject, eventdata, handles) 

varargout{1} = handles.output;


% --- Executes on button press in PushbuttonGrid.
function PushbuttonGrid_Callback(hObject, eventdata, handles)



% --- Executes on button press in Back2second.
function Back2second_Callback(hObject, eventdata, handles)

set(findobj('Tag','EyePushbutton1'),'Enable','on');
delete(gcf);


% --- Executes on button press in eyepushbuttoni.
function EyePushbuttonI_Callback(hObject, eventdata, handles)
global A LSAMPL MODULATOR

set(handles.PushbuttonGrid,'Enable','on');

colors = rand(10,3);

set(handles.EyeAxes1,'NextPlot','replace');

 for i = 1:10
     plot(handles.EyeAxes1,A(1,i*2*LSAMPL+1:(i+1)*2*LSAMPL+2),'Color',colors(i,:));
     
     if strcmp(get(handles.EyeAxes1,'NextPlot'),'replace')
        set(handles.EyeAxes1,'NextPlot','add');
     end
 end

box off; 
if ~strcmp(MODULATOR,'8psk')
    line([0 2*LSAMPL+2],[0 0],'Color','k');
end
set(gca,'Xlim',[0 2*LSAMPL+2], 'XTick', 1:LSAMPL:2*LSAMPL+2,'XTickLabel',1:LSAMPL:2*LSAMPL+2);
switch MODULATOR
       case 'bpsk'
          set(gca,'Ylim',[-1.5 1.5],'YTick',-1:1);
       case 'qpsk'
          set(gca,'Ylim',[-1 1],'YTick',-sqrt(2)/2:sqrt(2)/2:sqrt(2)/2);
       case '8psk'
          set(gca,'Ylim',[-1.5 1.5],'YTick',[-1 -sqrt(2)/2 0 sqrt(2)/2 1]);
       case 'bqam'
          set(gca,'Ylim',[-1.5 1.5],'YTick',-1:1);
       case '16qam'
          set(gca,'Ylim',[-2 2],'YTick',[-3/sqrt(10) -1/sqrt(10) 0 1/sqrt(10) 3/sqrt(10)]);
       case '64qam'
          set(gca,'Ylim',[-2 2],'YTick',[(-7)/(sqrt(42))  (-5)/(sqrt(42)) (-3)/(sqrt(42)) (-1)/(sqrt(42)) 0 1/(sqrt(42)) 3/(sqrt(42)) 5/(sqrt(42)) 7/(sqrt(42))]);
end  
l=get(gca,'XLabel');
m=get(gca,'YLabel');
n=get(gca,'Title');
set(l,'String','�������� ','Color',[.5 .5 .5],'FontName','Calibri','FontSize',11,'FontAngle','oblique');
set(m,'String','������ ���������� ���������� I','Color',[.5 .5 .5],'FontName','Calibri',...
'FontSize',11,'FontAngle','oblique');
set(n,'String','A��������� ���������� ����������, �','Color',[.5 .5 .5],...
'FontName','Calibri','FontWeight','bold','FontSize',11,'FontAngle','normal');

% plot(handles.EyeAxes1,0:2*LSAMPL+2)

% --- Executes on button press in EyePushbuttonQ.
function EyePushbuttonQ_Callback(hObject, eventdata, handles)

global B LSAMPL MODULATOR

set(handles.PushbuttonGrid,'Enable','on');

colors = rand(10,3);

     set(handles.EyeAxes1,'NextPlot','replace');

 for i = 1:10
     plot(handles.EyeAxes1,B(1,i*2*LSAMPL+1:(i+1)*2*LSAMPL+2),'Color',colors(i,:));
     
     if strcmp(get(handles.EyeAxes1,'NextPlot'),'replace')
        set(handles.EyeAxes1,'NextPlot','add');
     end
 end

box off;
if ~strcmp(MODULATOR,'8psk')
   line([0 2*LSAMPL+2],[0 0],'Color','k');
end
set(gca,'Xlim',[0 2*LSAMPL+2], 'XTick', 1:LSAMPL:2*LSAMPL+2,'XTickLabel',1:LSAMPL:2*LSAMPL+2);
switch MODULATOR
       case 'bpsk'
          set(gca,'Ylim',[-1.5 1.5],'YTick',-1:1);
       case 'qpsk'
          set(gca,'Ylim',[-1 1],'YTick',-sqrt(2)/2:sqrt(2)/2:sqrt(2)/2);
       case '8psk'
          set(gca,'Ylim',[-1.5 1.5],'YTick',[-1 -sqrt(2)/2 0 sqrt(2)/2 1]);
       case 'bqam'
          set(gca,'Ylim',[-1.5 1.5],'YTick',-1:1);
       case '16qam'
          set(gca,'Ylim',[-2 2],'YTick',[-3/sqrt(10) -1/sqrt(10) 0 1/sqrt(10) 3/sqrt(10)]);
       case '64qam'
          set(gca,'Ylim',[-2 2],'YTick',[(-7)/(sqrt(42))  (-5)/(sqrt(42)) (-3)/(sqrt(42)) (-1)/(sqrt(42)) 0 1/(sqrt(42)) 3/(sqrt(42)) 5/(sqrt(42)) 7/(sqrt(42))]);
end  
l=get(gca,'XLabel');
m=get(gca,'YLabel');
n=get(gca,'Title');
set(l,'String','�������� ','Color',[.5 .5 .5],'FontName','Calibri','FontSize',11,'FontAngle','oblique');
set(m,'String','������ ���������� ���������� Q','Color',[.5 .5 .5],'FontName','Calibri',...
'FontSize',11,'FontAngle','oblique');
set(n,'String','A��������� ���������� ����������, Q','Color',[.5 .5 .5],...
'FontName','Calibri','FontWeight','bold','FontSize',11,'FontAngle','normal');



% --- Executes during object deletion, before destroying properties.
function SimulEye_DeleteFcn(hObject, eventdata, handles)

e = findobj('Tag','EyePushbutton1');
set(e,'Enable','on');




%
