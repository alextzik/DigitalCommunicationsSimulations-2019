function varargout = ImpulseRF(varargin)

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @ImpulseRF_OpeningFcn, ...
                   'gui_OutputFcn',  @ImpulseRF_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before ImpulseRF is made visible.
function ImpulseRF_OpeningFcn(hObject, eventdata, handles, varargin)
global cf cf2

handles.output = hObject;
guidata(hObject, handles);

im = findobj('Tag','ImpulseResponse');
set(im,'Enable','off');
set(handles.EditCutFactor2,'String',cf);
cf2 = cf;


% --- Outputs from this function are returned to the command line.
function varargout = ImpulseRF_OutputFcn(hObject, eventdata, handles) 

varargout{1} = handles.output;


% --- Executes on button press in GridPushbutton.
function GridPushbutton_Callback(hObject, eventdata, handles)
grid

% --- Executes on button press in Back2Third.
function Back2Third_Callback(hObject, eventdata, handles)

im = findobj('Tag','ImpulseResponse');
set(im,'Enable','on');
close(gcf);


function EditCutFactor2_Callback(hObject, eventdata, handles)
global cf2 

ecf2 = get(handles.EditCutFactor2,'String');
cf2 = str2num(ecf2);

% --- Executes during object creation, after setting all properties.
function EditCutFactor2_CreateFcn(hObject, eventdata, handles)

if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in impulse.
function impulse_Callback(hObject, eventdata, handles)
global LSAMPL cf2 T


if length(cf2)>1 || ~isreal(cf2) || isempty(cf2)
    warndlg('������ �� ���������� ���� ������ ���� ��� edit box!');
    return;
elseif cf2<0 || cf2>1
    warndlg('������ �� ���������� ���� �������� ������ ���� ��� �������� [0,1]!');
    return;
end

delay = 16;
offset = delay*LSAMPL;
Tsum = T*2*delay;
rrc=rcosine(1,LSAMPL,'fir/sqrt',cf2,delay);
plot(handles.ImpulseAxes1,0:Tsum/(2*offset):Tsum,rrc,'Color',[.306 .396 .58]);
set(handles.ImpulseAxes1,'XLim',[0 Tsum],'XTick',0:T:Tsum);
ylim([-0.07 0.4]);
xlabel('������  (�s)','Color',[.5 .5 .5],'FontName','Calibri','FontSize',11,'FontAngle','oblique');
ylabel('������ (mV)','Color',[.5 .5 .5],'FontName','Calibri',...
   'FontSize',11,'FontAngle','oblique');

l = legend(handles.ImpulseAxes1,'������ ����� ���������� �����������');
set(l,'EdgeColor',[.8 .8 .8],'FontName','Calibri');

box off;
set(handles.impulse,'Enable','off');
set(handles.GridPushbutton,'Enable','on');




% --- Executes on key press with focus on EditCutFactor2 and none of its controls.
function EditCutFactor2_KeyPressFcn(hObject, eventdata, handles)
set(handles.impulse,'Enable','on');


% --- Executes during object deletion, before destroying properties.
function ImpulseRF_DeleteFcn(hObject, eventdata, handles)
ip = findobj('Tag','ImpulseResponse');
set(ip,'Enable','on');



%
