function varargout = SimulSpace(varargin)

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @SimulSpace_OpeningFcn, ...
                   'gui_OutputFcn',  @SimulSpace_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT

function SimulSpace_OpeningFcn(hObject, eventdata, handles, varargin)
global MODULATOR LSAMPL

handles.output = hObject;
guidata(hObject, handles);

set(findobj('Tag','SpacePushbutton1'),'Enable','off');

keimeno = sprintf('������ �������������� (1 - %d)',LSAMPL);
set(handles.uipanel1,'Title',keimeno);

switch MODULATOR
    case 'bpsk'
         set(findobj('Tag','EditAxesY'),'Enable','off');
         set(handles.StarTitle,'String','���������� BPSK');
         set(handles.SimulSpace,'Name','BPSK ����: ��������� �����');
         
    case 'qpsk'
         set(handles.StarTitle,'String','���������� QPSK');
         set(handles.SimulSpace,'Name','QPSK ����: ��������� �����');
         
    case '8psk'
         set(handles.StarTitle,'String','���������� 8PSK');
         set(handles.SimulSpace,'Name','8PSK ����: ��������� �����');
         
    case 'bqam'
         set(findobj('Tag','EditAxesY'),'Enable','off');
         set(handles.StarTitle,'String','���������� BQAM');
         set(handles.SimulSpace,'Name','BQAM ����: ��������� �����');
         
    case '16qam'
         set(handles.StarTitle,'String','���������� 16QAM');
         set(handles.SimulSpace,'Name','16QAM ����: ��������� �����');
         
    case '64qam'
         set(handles.StarTitle,'String','���������� 64QAM');
         set(handles.SimulSpace,'Name','64QAM ����: ��������� �����');
end

function varargout = SimulSpace_OutputFcn(hObject, eventdata, handles) 
varargout{1} = handles.output;
    
function EditAxesX_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function EditAxesY_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function Back2Second1_Callback(hObject, eventdata, handles)
clear global h1 x y
set(findobj('Tag','SpacePushbutton1'),'Enable','on');
delete(gcf);

function SpacePushbutton_Callback(hObject, eventdata, handles)
global A B h1 LSAMPL x y MODULATOR

% ������� ��� edit boxes
switch MODULATOR
    
    case 'bpsk'
        if isempty(x) || round(x)~=x || length(x)>1 || ~isreal(x) 
              warndlg('������ �� ���������� ���� ������ ������� ������ ��� edit box!');
             return;   
        elseif x<1 || x>LSAMPL
              warndlg('������ �� ���������� ���� ������ ������� ���� ��� ����� ��� ������� ��������������!');
             return;   
        end
        
    case 'bqam'
        if isempty(x) || round(x)~=x || length(x)>1 || ~isreal(x) 
              warndlg('������ �� ���������� ���� ������ ������� ������ ��� edit box!');
             return;   
        elseif x<1 || x>LSAMPL
              warndlg('������ �� ���������� ���� ������ ������� ���� ��� ����� ��� ������� ��������������!');
             return;   
        end
         
    otherwise
        if isempty(x) || isempty(y)
              warndlg('������ �� ���������� �������� ���� ��� edit boxes!');
             return;   
        elseif round(x)~=x || round(y)~=y || length(x)>1 || length(y)>1 || ~isreal(x) || ~isreal(y)
              warndlg('������ �� ���������� ��� ���� ������ ������� ������ �� ���� edit box!');
             return;   
        elseif x<1 || x>LSAMPL || y<1 || y>LSAMPL
              warndlg('������ �� ���������� ��� �������� ��������� ���� ��� ����� ��� ������� ��������������!');
             return;   
        end
end



switch MODULATOR
    case 'bpsk'
            switch h1     
                case 2
                     scatter(handles.SpaceAxes1,A(x:LSAMPL:end),B(1:LSAMPL:end),'.','MarkerEdgeColor',[.87 .49 0],'MarkerFaceColor',[.87 .49 0]);

                case 3
                     scatter(handles.SpaceAxes1,A(x:LSAMPL:end),B(1:LSAMPL:end),'d','MarkerEdgeColor',[.87 .49 0],'MarkerFaceColor',[.87 .49 0]);
            end
            text(.9,0.4,'\bf \sl \fontsize{11} \color[rgb]{.04 .52 .78} 1');
            text(-1.1,0.4,'\bf \sl \fontsize{11} \color[rgb]{.04 .52 .78} 0');
            
            set(gca,'Xlim',[-1.5 1.5],'XTick',-1:1);   
            set(gca,'Ylim',[-2 2],'YTick',-1:1);
            
            line([0 0],[-2 2],'Color','k','LineStyle','--');
            
    case 'qpsk'
        switch h1     
                case 2
                     scatter(handles.SpaceAxes1,A(x:LSAMPL:end),B(y:LSAMPL:end),'.','MarkerEdgeColor',[.87 .49 0],'MarkerFaceColor',[.87 .49 0]);
                     
                case 3
                     scatter(handles.SpaceAxes1,A(x:LSAMPL:end),B(y:LSAMPL:end),'d','MarkerEdgeColor',[.87 .49 0],'MarkerFaceColor',[.87 .49 0]);
        end
        text(0.7,0.8,'\bf \sl \fontsize{11} \color[rgb]{.04 .52 .78} 00');
        text(-0.95,-0.8,'\bf \sl \fontsize{11} \color[rgb]{.04 .52 .78} 11');
        text(-0.95,0.8,'\bf \sl \fontsize{11} \color[rgb]{.04 .52 .78} 01');
        text(0.7,-0.8,'\bf \sl \fontsize{11} \color[rgb]{.04 .52 .78} 10');
        
        set(gca,'Xlim',[-1.5 1.5],'XTick',-sqrt(2)/2:sqrt(2)/2:sqrt(2)/2);   
        set(gca,'Ylim',[-2 2],'YTick',-sqrt(2)/2:sqrt(2)/2:sqrt(2)/2);
        
        line([0 0],[-sqrt(2)/2 sqrt(2)/2],'Color','k','LineStyle','--');
        line([-sqrt(2)/2 sqrt(2)/2],[0 0],'Color','k','LineStyle','--');
        


    case '8psk'
        switch h1     
                case 2
                     scatter(handles.SpaceAxes1,A(x:LSAMPL:end),B(y:LSAMPL:end),'.','MarkerEdgeColor',[.87 .49 0],'MarkerFaceColor',[.87 .49 0]);
                     
                case 3
                     scatter(handles.SpaceAxes1,A(x:LSAMPL:end),B(y:LSAMPL:end),'d','MarkerEdgeColor',[.87 .49 0],'MarkerFaceColor',[.87 .49 0]);
        end
        text(1,-0.01,'\bf \sl \fontsize{11} \color[rgb]{.04 .52 .78} 111');
        text(0.7,0.8,'\bf \sl \fontsize{11} \color[rgb]{.04 .52 .78} 110');
        text(-0.1,1.2,'\bf \sl \fontsize{11} \color[rgb]{.04 .52 .78} 010');
        text(-0.95,0.8,'\bf \sl \fontsize{11} \color[rgb]{.04 .52 .78} 011');
        text(-1.25,-0.01,'\bf \sl \fontsize{11} \color[rgb]{.04 .52 .78} 001');
        text(-0.95,-0.8,'\bf \sl \fontsize{11} \color[rgb]{.04 .52 .78} 000');
        text(-0.1,-1.2,'\bf \sl \fontsize{11} \color[rgb]{.04 .52 .78} 100');
        text(0.7,-0.8,'\bf \sl \fontsize{11} \color[rgb]{.04 .52 .78} 101');
        
        set(gca,'Xlim',[-1.5 1.5],'XTick',[-1 -sqrt(2)/2 0 sqrt(2)/2 1]);   
        set(gca,'Ylim',[-1.5 1.5],'YTick',[-1 -sqrt(2)/2 0 sqrt(2)/2 1]);
        
        line([-tan(pi/8) tan(pi/8)],[-1 1],'Color','k','LineStyle','--');
        line([tan(pi/8) -tan(pi/8)],[-1 1],'Color','k','LineStyle','--');
        line([-1 1],[-tan(pi/8) tan(pi/8)],'Color','k','LineStyle','--');
        line([-1 1],[tan(pi/8) -tan(pi/8)],'Color','k','LineStyle','--');
        


case 'bqam'
            switch h1     
                case 2
                     scatter(handles.SpaceAxes1,A(x:LSAMPL:end),B(1:LSAMPL:end),'.','MarkerEdgeColor',[.87 .49 0],'MarkerFaceColor',[.87 .49 0]);

                case 3
                     scatter(handles.SpaceAxes1,A(x:LSAMPL:end),B(1:LSAMPL:end),'d','MarkerEdgeColor',[.87 .49 0],'MarkerFaceColor',[.87 .49 0]);
            end
            text(.9,0.4,'\bf \sl \fontsize{11} \color[rgb]{.04 .52 .78} 1');
            text(-1.1,0.4,'\bf \sl \fontsize{11} \color[rgb]{.04 .52 .78} 0');
            
            set(gca,'Xlim',[-1.5 1.5],'XTick',-1:1);   
            set(gca,'Ylim',[-2 2],'YTick',-1:1);
            
            line([0 0],[-2 2],'Color','k','LineStyle','--');

 case '16qam'
        switch h1     
                case 2
                     scatter(handles.SpaceAxes1,A(x:LSAMPL:end),B(y:LSAMPL:end),'.','MarkerEdgeColor',[.87 .49 0],'MarkerFaceColor',[.87 .49 0]);
                     
                case 3
                     scatter(handles.SpaceAxes1,A(x:LSAMPL:end),B(y:LSAMPL:end),'d','MarkerEdgeColor',[.87 .49 0],'MarkerFaceColor',[.87 .49 0]);
        end
        text(-3.4/sqrt(10),2.7/sqrt(10),'\bf \sl \fontsize{11} \color[rgb]{.04 .52 .78} 0000');
        text(-3.4/sqrt(10),0.7/sqrt(10),'\bf \sl \fontsize{11} \color[rgb]{.04 .52 .78} 0001');
        text(-3.4/sqrt(10),-1.3/sqrt(10),'\bf \sl \fontsize{11} \color[rgb]{.04 .52 .78} 0011');
        text(-3.4/sqrt(10),-3.3/sqrt(10),'\bf \sl \fontsize{11} \color[rgb]{.04 .52 .78} 0010');
        text(-1.4/sqrt(10),2.7/sqrt(10),'\bf \sl \fontsize{11} \color[rgb]{.04 .52 .78} 0100');
        text(-1.4/sqrt(10),0.7/sqrt(10),'\bf \sl \fontsize{11} \color[rgb]{.04 .52 .78} 0101');
        text(-1.4/sqrt(10),-1.3/sqrt(10),'\bf \sl \fontsize{11} \color[rgb]{.04 .52 .78} 0111');
        text(-1.4/sqrt(10),-3.3/sqrt(10),'\bf \sl \fontsize{11} \color[rgb]{.04 .52 .78} 0110');
        text(0.6/sqrt(10),2.7/sqrt(10),'\bf \sl \fontsize{11} \color[rgb]{.04 .52 .78} 1100');
        text(0.6/sqrt(10),0.7/sqrt(10),'\bf \sl \fontsize{11} \color[rgb]{.04 .52 .78} 1101');
        text(0.6/sqrt(10),-1.3/sqrt(10),'\bf \sl \fontsize{11} \color[rgb]{.04 .52 .78} 1111');
        text(0.6/sqrt(10),-3.3/sqrt(10),'\bf \sl \fontsize{11} \color[rgb]{.04 .52 .78} 1110');
        text(2.6/sqrt(10),2.7/sqrt(10),'\bf \sl \fontsize{11} \color[rgb]{.04 .52 .78} 1000');
        text(2.6/sqrt(10),0.7/sqrt(10),'\bf \sl \fontsize{11} \color[rgb]{.04 .52 .78} 1001');
        text(2.6/sqrt(10),-1.3/sqrt(10),'\bf \sl \fontsize{11} \color[rgb]{.04 .52 .78} 1011');
        text(2.6/sqrt(10),-3.3/sqrt(10),'\bf \sl \fontsize{11} \color[rgb]{.04 .52 .78} 1010');
        
        set(gca,'Xlim',[-2 2],'XTick',[-3/sqrt(10) -2/sqrt(10) -1/sqrt(10) 0 1/sqrt(10) 2/sqrt(10) 3/sqrt(10)]);   
        set(gca,'Ylim',[-2 2],'YTick',[-3/sqrt(10) -2/sqrt(10) -1/sqrt(10) 0 1/sqrt(10) 2/sqrt(10) 3/sqrt(10)]);
        
        line([-2 2],[2/sqrt(10) 2/sqrt(10)],'Color','k','LineStyle','--');
        line([-2 2],[0 0],'Color','k','LineStyle','--');
        line([-2 2],[-2/sqrt(10) -2/sqrt(10)],'Color','k','LineStyle','--');
        line([-2/sqrt(10) -2/sqrt(10)],[-2 2],'Color','k','LineStyle','--');
        line([0 0],[-2 2],'Color','k','LineStyle','--');
        line([2/sqrt(10) 2/sqrt(10)],[-2 2],'Color','k','LineStyle','--');
        
   case '64qam'
        switch h1     
                case 2
                     scatter(handles.SpaceAxes1,A(x:LSAMPL:end),B(y:LSAMPL:end),'.','MarkerEdgeColor',[.87 .49 0],'MarkerFaceColor',[.87 .49 0]);
                     
                case 3
                     scatter(handles.SpaceAxes1,A(x:LSAMPL:end),B(y:LSAMPL:end),'d','MarkerEdgeColor',[.87 .49 0],'MarkerFaceColor',[.87 .49 0]);
        end
        text(-8.5/sqrt(42),6.5/sqrt(42),'\bf \sl \fontsize{9} \color[rgb]{.04 .52 .78} 100000');
        text(-8.5/sqrt(42),4.5/sqrt(42),'\bf \sl \fontsize{9} \color[rgb]{.04 .52 .78} 100001');
        text(-8.5/sqrt(42),2.5/sqrt(42),'\bf \sl \fontsize{9} \color[rgb]{.04 .52 .78} 100101');
        text(-8.5/sqrt(42),0.5/sqrt(42),'\bf \sl \fontsize{9} \color[rgb]{.04 .52 .78} 100100');
        text(-8.5/sqrt(42),-1.5/sqrt(42),'\bf \sl \fontsize{9} \color[rgb]{.04 .52 .78} 110100');
        text(-8.5/sqrt(42),-3.5/sqrt(42),'\bf \sl \fontsize{9} \color[rgb]{.04 .52 .78} 110101');
        text(-8.5/sqrt(42),-5.5/sqrt(42),'\bf \sl \fontsize{9} \color[rgb]{.04 .52 .78} 110001');
        text(-8.5/sqrt(42),-7.5/sqrt(42),'\bf \sl \fontsize{9} \color[rgb]{.04 .52 .78} 110000');
        text(-6.5/sqrt(42),6.5/sqrt(42),'\bf \sl \fontsize{9} \color[rgb]{.04 .52 .78} 100010');
        text(-6.5/sqrt(42),4.5/sqrt(42),'\bf \sl \fontsize{9} \color[rgb]{.04 .52 .78} 100011');
        text(-6.5/sqrt(42),2.5/sqrt(42),'\bf \sl \fontsize{9} \color[rgb]{.04 .52 .78} 100111');
        text(-6.5/sqrt(42),0.5/sqrt(42),'\bf \sl \fontsize{9} \color[rgb]{.04 .52 .78} 100110');
        text(-6.5/sqrt(42),-1.5/sqrt(42),'\bf \sl \fontsize{9} \color[rgb]{.04 .52 .78} 110110');
        text(-6.5/sqrt(42),-3.5/sqrt(42),'\bf \sl \fontsize{9} \color[rgb]{.04 .52 .78} 110111');
        text(-6.5/sqrt(42),-5.5/sqrt(42),'\bf \sl \fontsize{9} \color[rgb]{.04 .52 .78} 110011');
        text(-6.5/sqrt(42),-7.5/sqrt(42),'\bf \sl \fontsize{9} \color[rgb]{.04 .52 .78} 110010');
        text(-4.5/sqrt(42),6.5/sqrt(42),'\bf \sl \fontsize{9} \color[rgb]{.04 .52 .78} 101010');
        text(-4.5/sqrt(42),4.5/sqrt(42),'\bf \sl \fontsize{9} \color[rgb]{.04 .52 .78} 101011');
        text(-4.5/sqrt(42),2.5/sqrt(42),'\bf \sl \fontsize{9} \color[rgb]{.04 .52 .78} 101111');
        text(-4.5/sqrt(42),0.5/sqrt(42),'\bf \sl \fontsize{9} \color[rgb]{.04 .52 .78} 101110');
        text(-4.5/sqrt(42),-1.5/sqrt(42),'\bf \sl \fontsize{9} \color[rgb]{.04 .52 .78} 111110');
        text(-4.5/sqrt(42),-3.5/sqrt(42),'\bf \sl \fontsize{9} \color[rgb]{.04 .52 .78} 111111');
        text(-4.5/sqrt(42),-5.5/sqrt(42),'\bf \sl \fontsize{9} \color[rgb]{.04 .52 .78} 111011');
        text(-4.5/sqrt(42),-7.5/sqrt(42),'\bf \sl \fontsize{9} \color[rgb]{.04 .52 .78} 111010');
        text(-2.5/sqrt(42),6.5/sqrt(42),'\bf \sl \fontsize{9} \color[rgb]{.04 .52 .78} 101000');
        text(-2.5/sqrt(42),4.5/sqrt(42),'\bf \sl \fontsize{9} \color[rgb]{.04 .52 .78} 101001');
        text(-2.5/sqrt(42),2.5/sqrt(42),'\bf \sl \fontsize{9} \color[rgb]{.04 .52 .78} 101101');
        text(-2.5/sqrt(42),0.5/sqrt(42),'\bf \sl \fontsize{9} \color[rgb]{.04 .52 .78} 101100');
        text(-2.5/sqrt(42),-1.5/sqrt(42),'\bf \sl \fontsize{9} \color[rgb]{.04 .52 .78} 111100');
        text(-2.5/sqrt(42),-3.5/sqrt(42),'\bf \sl \fontsize{9} \color[rgb]{.04 .52 .78} 111101');
        text(-2.5/sqrt(42),-5.5/sqrt(42),'\bf \sl \fontsize{9} \color[rgb]{.04 .52 .78} 111001');
        text(-2.5/sqrt(42),-7.5/sqrt(42),'\bf \sl \fontsize{9} \color[rgb]{.04 .52 .78} 111000');
        text(-0.5/sqrt(42),6.5/sqrt(42),'\bf \sl \fontsize{9} \color[rgb]{.04 .52 .78} 001000');
        text(-0.5/sqrt(42),4.5/sqrt(42),'\bf \sl \fontsize{9} \color[rgb]{.04 .52 .78} 001001');
        text(-0.5/sqrt(42),2.5/sqrt(42),'\bf \sl \fontsize{9} \color[rgb]{.04 .52 .78} 001101');
        text(-0.5/sqrt(42),0.5/sqrt(42),'\bf \sl \fontsize{9} \color[rgb]{.04 .52 .78} 001100');
        text(-0.5/sqrt(42),-1.5/sqrt(42),'\bf \sl \fontsize{9} \color[rgb]{.04 .52 .78} 011100');
        text(-0.5/sqrt(42),-3.5/sqrt(42),'\bf \sl \fontsize{9} \color[rgb]{.04 .52 .78} 011101');
        text(-0.5/sqrt(42),-5.5/sqrt(42),'\bf \sl \fontsize{9} \color[rgb]{.04 .52 .78} 011001');
        text(-0.5/sqrt(42),-7.5/sqrt(42),'\bf \sl \fontsize{9} \color[rgb]{.04 .52 .78} 011000');
        text(1.5/sqrt(42),6.5/sqrt(42),'\bf \sl \fontsize{9} \color[rgb]{.04 .52 .78} 001010');
        text(1.5/sqrt(42),4.5/sqrt(42),'\bf \sl \fontsize{9} \color[rgb]{.04 .52 .78} 001011');
        text(1.5/sqrt(42),2.5/sqrt(42),'\bf \sl \fontsize{9} \color[rgb]{.04 .52 .78} 001111');
        text(1.5/sqrt(42),0.5/sqrt(42),'\bf \sl \fontsize{9} \color[rgb]{.04 .52 .78} 001110');
        text(1.5/sqrt(42),-1.5/sqrt(42),'\bf \sl \fontsize{9} \color[rgb]{.04 .52 .78} 011110');
        text(1.5/sqrt(42),-3.5/sqrt(42),'\bf \sl \fontsize{9} \color[rgb]{.04 .52 .78} 011111');
        text(1.5/sqrt(42),-5.5/sqrt(42),'\bf \sl \fontsize{9} \color[rgb]{.04 .52 .78} 011011');
        text(1.5/sqrt(42),-7.5/sqrt(42),'\bf \sl \fontsize{9} \color[rgb]{.04 .52 .78} 011010');
        text(3.5/sqrt(42),6.5/sqrt(42),'\bf \sl \fontsize{9} \color[rgb]{.04 .52 .78} 000010');
        text(3.5/sqrt(42),4.5/sqrt(42),'\bf \sl \fontsize{9} \color[rgb]{.04 .52 .78} 000011');
        text(3.5/sqrt(42),2.5/sqrt(42),'\bf \sl \fontsize{9} \color[rgb]{.04 .52 .78} 000111');
        text(3.5/sqrt(42),0.5/sqrt(42),'\bf \sl \fontsize{9} \color[rgb]{.04 .52 .78} 000110');
        text(3.5/sqrt(42),-1.5/sqrt(42),'\bf \sl \fontsize{9} \color[rgb]{.04 .52 .78} 010110');
        text(3.5/sqrt(42),-3.5/sqrt(42),'\bf \sl \fontsize{9} \color[rgb]{.04 .52 .78} 010111');
        text(3.5/sqrt(42),-5.5/sqrt(42),'\bf \sl \fontsize{9} \color[rgb]{.04 .52 .78} 010011');
        text(3.5/sqrt(42),-7.5/sqrt(42),'\bf \sl \fontsize{9} \color[rgb]{.04 .52 .78} 010010');
        text(5.5/sqrt(42),6.5/sqrt(42),'\bf \sl \fontsize{9} \color[rgb]{.04 .52 .78} 000000');
        text(5.5/sqrt(42),4.5/sqrt(42),'\bf \sl \fontsize{9} \color[rgb]{.04 .52 .78} 000001');
        text(5.5/sqrt(42),2.5/sqrt(42),'\bf \sl \fontsize{9} \color[rgb]{.04 .52 .78} 000101');
        text(5.5/sqrt(42),0.5/sqrt(42),'\bf \sl \fontsize{9} \color[rgb]{.04 .52 .78} 000100');
        text(5.5/sqrt(42),-1.5/sqrt(42),'\bf \sl \fontsize{9} \color[rgb]{.04 .52 .78} 010100');
        text(5.5/sqrt(42),-3.5/sqrt(42),'\bf \sl \fontsize{9} \color[rgb]{.04 .52 .78} 010101');
        text(5.5/sqrt(42),-5.5/sqrt(42),'\bf \sl \fontsize{9} \color[rgb]{.04 .52 .78} 010001');
        text(5.5/sqrt(42),-7.5/sqrt(42),'\bf \sl \fontsize{9} \color[rgb]{.04 .52 .78} 010000');
        
        
        
        set(gca,'Xlim',[-2 2],'XTick',[-1.08 -0.77 -0.46 -0.15 0 0.15 0.46 0.77 1.08]);   
        set(gca,'Ylim',[-2 2],'YTick',[-1.08 -0.77 -0.46 -0.15 0 0.15 0.46 0.77 1.08]);
        
        
        line([-2 2],[6/sqrt(42) 6/sqrt(42)],'Color','k','LineStyle','--');
        line([-2 2],[4/sqrt(42) 4/sqrt(42)],'Color','k','LineStyle','--');
        line([-2 2],[2/sqrt(42) 2/sqrt(42)],'Color','k','LineStyle','--');
        line([-2 2],[0 0],'Color','k','LineStyle','--');
        line([-2 2],[-2/sqrt(42) -2/sqrt(42)],'Color','k','LineStyle','--');
        line([-2 2],[-4/sqrt(42) -4/sqrt(42)],'Color','k','LineStyle','--');
        line([-2 2],[-6/sqrt(42) -6/sqrt(42)],'Color','k','LineStyle','--');
        
        line([-6/sqrt(42) -6/sqrt(42)],[-2 2],'Color','k','LineStyle','--');
        line([-4/sqrt(42) -4/sqrt(42)],[-2 2],'Color','k','LineStyle','--');
        line([-2/sqrt(42) -2/sqrt(42)],[-2 2],'Color','k','LineStyle','--');
        line([0 0],[-2 2],'Color','k','LineStyle','--');
        line([2/sqrt(42) 2/sqrt(42)],[-2 2],'Color','k','LineStyle','--');
        line([4/sqrt(42) 4/sqrt(42)],[-2 2],'Color','k','LineStyle','--');
        line([6/sqrt(42) 6/sqrt(42)],[-2 2],'Color','k','LineStyle','--');
end

xlabel('������ ���������� ����������, I','Color',[.5 .5 .5],'FontName','Calibri','FontSize',11,'FontAngle','oblique');
ylabel('������ ���������� ����������, Q','Color',[.5 .5 .5],'FontName','Calibri','FontSize',11,'FontAngle','oblique');

set(handles.PushbuttonGrid,'Enable','on');

function TrackSize_Callback(hObject, eventdata, handles)
global x y h1 MODULATOR

h1 = get(handles.TrackSize,'Value');

switch MODULATOR
    case 'bpsk'    
        if ~isempty(x) && h1>1
            set(handles.SpacePushbutton,'Enable','on');
        else
            set(handles.SpacePushbutton,'Enable','off');
        end
        
    case 'bqam'    
        if ~isempty(x) && h1>1
            set(handles.SpacePushbutton,'Enable','on');
        else
            set(handles.SpacePushbutton,'Enable','off');
        end
        
    otherwise
        if ~isempty(x) && ~isempty(y) && h1>1
           set(handles.SpacePushbutton,'Enable','on');
        else
           set(handles.SpacePushbutton,'Enable','off');
        end
end

function TrackSize_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function PushbuttonGrid_Callback(hObject, eventdata, handles)
grid;

function EditAxesX_KeyPressFcn(hObject, eventdata, handles)
global h1 y MODULATOR

  switch MODULATOR
     case 'bpsk'             
         if h1 > 1
             set(handles.SpacePushbutton,'Enable','on');
         end
     
     case 'bqam'             
         if h1 > 1
             set(handles.SpacePushbutton,'Enable','on');
         end
        
     otherwise         
         if h1 > 1 && ~isempty(y)
           set(handles.SpacePushbutton,'Enable','on');
         end
  end

function EditAxesY_KeyPressFcn(hObject, eventdata, handles)
global h1 x

  if h1 > 1 && ~isempty(x)
    set(handles.SpacePushbutton,'Enable','on');
  end

function EditAxesX_Callback(hObject, eventdata, handles)
global x
    
  x = get(handles.EditAxesX,'String');
  x = str2num(x);  

function EditAxesY_Callback(hObject, eventdata, handles)
global y

  y = get(handles.EditAxesY,'String');
  y = str2num(y);

function SimulSpace_DeleteFcn(hObject, eventdata, handles)
clear global h1 x y
s = findobj('Tag','SpacePushbutton1');
set(s,'Enable','on');




