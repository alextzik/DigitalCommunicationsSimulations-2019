function varargout = wgnAutoCor(varargin)

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @wgnAutoCor_OpeningFcn, ...
                   'gui_OutputFcn',  @wgnAutoCor_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT

function wgnAutoCor_OpeningFcn(hObject, eventdata, handles, varargin)
global timeCor lags

handles.output = hObject;
guidata(hObject, handles);

s = -lags(1,1);
    
plot(handles.wgnAxes2,-s:-1,timeCor(1,1:s),'Color',[184 65 22]/256);    
h = stem(handles.wgnAxes2,0,timeCor(1,s+1),'.','Color',[184 65 22]/256);
base = get(h,'BaseLine'); set(base,'LineStyle','none');
plot(handles.wgnAxes2,1:s,timeCor(1,s+2:length(lags)),'Color',[184 65 22]/256);
xlim(handles.wgnAxes2,[-s s]);

title(gca,'��������� �������������� WN','Color',[.5,.5,.5],...
   'FontName','Calibri','FontWeight','bold','FontSize',11,'FontAngle','normal');
ylabel(gca,'������,(mV^2)','Color',[.5,.5,.5],'FontName','Calibri',...
   'FontSize',11,'FontAngle','oblique');
xlabel(gca,'������� ���������, �','Color',[.5,.5,.5],'FontName','Calibri','FontSize',11,'FontAngle','oblique');
l = legend('�������������');
set(l,'EdgeColor',[.8 .8 .8],'FontName','Calibri');

function varargout = wgnAutoCor_OutputFcn(hObject, eventdata, handles) 
varargout{1} = handles.output;

function PushbuttonGrid_Callback(hObject, eventdata, handles)
grid;

function Back2wgn_Callback(hObject, eventdata, handles)
t = findobj('Tag','AutoCorPushbutton3');
set(t,'Enable','on');
delete(gcf);

function wgnAutoCor_DeleteFcn(hObject, eventdata, handles)
t = findobj('Tag','AutoCorPushbutton3');
set(t,'Enable','on');


%
